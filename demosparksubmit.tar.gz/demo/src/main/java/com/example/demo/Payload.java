package com.example.demo;

public class Payload {

	private String applepierating;
	private String babygourmetrating;
	private String capuccinorating;
	private String coconutwaterrating;
	private String energydrinkrating;
	private String fruitpunchrating;
	private String oatmealcookiesrating;
	private String popchipsrating;
	
	
	public String getapplepierating() {
		return applepierating;
	}
	public void setapplepierating(String applepierating) {
		this.applepierating = applepierating;
	}
	public String getbabygourmetrating() {
		return babygourmetrating;
	}
	public void setbabygourmetrating(String babygourmetrating) {
		this.babygourmetrating = babygourmetrating;
	}
	public String getcapuccinorating() {
		return capuccinorating;
	}
	public void setcapuccinorating(String capuccinorating) {
		this.capuccinorating = capuccinorating;
	}
	public String getcoconutwaterrating() {
		return coconutwaterrating;
	}
	public void setcoconutwaterrating(String coconutwaterrating) {
		this.coconutwaterrating = coconutwaterrating;
	}
	public String getenergydrinkrating() {
		return energydrinkrating;
	}
	public void setenergydrinkrating(String energydrinkrating) {
		this.energydrinkrating = energydrinkrating;
	}
	public String getfruitpunchrating() {
		return fruitpunchrating;
	}
	public void setfruitpunchrating(String fruitpunchrating) {
		this.fruitpunchrating = fruitpunchrating;
	}
	public String getoatmealcookiesrating() {
		return oatmealcookiesrating;
	}
	public void setoatmealcookiesrating(String oatmealcookiesrating) {
		this.oatmealcookiesrating = oatmealcookiesrating;
	}
	public String getpopchipsrating() {
		return popchipsrating;
	}
	public void setpopchipsrating(String popchipsrating) {
		this.popchipsrating = popchipsrating;
	}
	
	
	
}
