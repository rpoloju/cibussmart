package com.example.demo;

import java.io.IOException;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class HtmlParser {
	
	public String pageTitle(String args) throws IOException {
		Connection conn = Jsoup.connect(args);
		if (conn != null) {
			Document doc = conn.get();
			if (doc != null && doc.title() != null) {
				return doc.title();
			}
		}
		return "N";
		
	}

}
